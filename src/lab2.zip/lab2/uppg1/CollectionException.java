/*
 * F�rfattare: Simon Metsi & Mathias Andreasen
 * CollectionException.java
 */
package lab2.uppg1;

public class CollectionException extends Exception {

	public CollectionException(String message) {
		super (message);
	}
}
