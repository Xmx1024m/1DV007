package lab2.uppg5;

import javazoom.jl.decoder.JavaLayerException;

public interface AudioTrack {
	
	public void play() throws JavaLayerException;		// Starts audio track
	public void quit();		// Stops audio track
	
	
}
